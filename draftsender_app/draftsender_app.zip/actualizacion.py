import os
import sys
import json
import urllib.request
import ssl
import certifi
import subprocess
import time
import logging
from tkinter import messagebox

logger = logging.getLogger("DraftSender")

VERSION_FILE = os.path.join("data", "version.txt")
URL_API = "https://api.github.com/repos/azambrano18/draftsender/releases/latest"

def obtener_version_actual():
    """
    Obtiene la versión actual desde version.txt. Si no existe, lo crea con v0.0.0.
    """
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, "w") as f:
            f.write("v0.0.0")
        return "0.0.0"
    with open(VERSION_FILE, "r") as f:
        return f.read().strip().lstrip("v")

def actualizar_version_local(nueva_version: str):
    """
    Actualiza el archivo version.txt con la versión descargada.
    """
    with open(VERSION_FILE, "w") as f:
        f.write(f"v{nueva_version}")

def crear_hook(base, avance, barra_progreso, porcentaje_var, root, status_var):
    """
    Hook para mostrar progreso de descarga con urllib.request.urlretrieve
    """
    inicio = time.time()

    def hook(count, block_size, total_size):
        if total_size > 0:
            porcentaje = int((count * block_size * 100) / total_size)
            total = min(100, base + int(porcentaje * avance / 100))
            barra_progreso["value"] = total
            porcentaje_var.set(f"{total}%")
            tiempo = time.time() - inicio
            velocidad_kb = (count * block_size) / 1024 / tiempo if tiempo > 0 else 0
            status_var.set(f"Descargando... {velocidad_kb:.1f} KB/s")
            root.update_idletasks()

    return hook

def verificar_actualizacion(root, barra_progreso, porcentaje_var, frame_progreso, status_label, status_var, forzar=False):
    try:
        logger.info("===== INICIO DE PROCESO DE ACTUALIZACIÓN =====")
        status_var.set("Verificando actualizaciones...")
        status_label.pack(side="bottom", pady=(0, 5))
        root.update_idletasks()
        root.geometry("")

        context = ssl.create_default_context(cafile=certifi.where())
        with urllib.request.urlopen(URL_API, context=context) as response:
            data = json.loads(response.read())
            if data.get("name") != "DraftSender":
                logger.warning("Último release no es 'DraftSender'. Abortando verificación.")
                messagebox.showwarning("Sin versión válida", "El último release no corresponde a DraftSender.")
                return
            ultima_version = data["tag_name"].lstrip("v")
            assets = data["assets"]
            logger.info(f"Última versión disponible: {ultima_version}")

        version_local = obtener_version_actual()
        if not forzar and version_local == ultima_version:
            logger.info("Ya tienes la última versión.")
            status_var.set("Ya tienes la última versión instalada.")
            root.after(5000, lambda: status_var.set(""))
            frame_progreso.pack_forget()
            status_label.pack_forget()
            root.geometry("")
            logger.info("===== FIN DE PROCESO DE ACTUALIZACIÓN (sin cambios) =====")
            return

        if messagebox.askyesno("Actualización disponible", f"Hay una nueva versión ({ultima_version}). ¿Deseas descargarla ahora?"):
            ejecutable_actual = sys.executable

            if not ejecutable_actual.lower().endswith(".exe") or "python" in os.path.basename(ejecutable_actual).lower():
                logger.warning("Modo desarrollo detectado. No se reemplazará el ejecutable.")
                messagebox.showinfo("Modo desarrollo", "Estás ejecutando en modo desarrollo. No se realizará actualización automática.")
                frame_progreso.pack_forget()
                status_label.pack_forget()
                root.geometry("")
                logger.info("===== FIN DE PROCESO DE ACTUALIZACIÓN (modo desarrollo) =====")
                return

            exe_dir = os.path.dirname(ejecutable_actual)
            descargas = [a for a in assets if a["name"].endswith(".exe") and a["name"].lower().startswith("draftsender")]

            if not descargas:
                logger.warning("No se encontraron archivos ejecutables para actualizar.")
                messagebox.showwarning("No disponible", "No se encontró el archivo ejecutable de actualización.")
                return

            barra_progreso["value"] = 0
            porcentaje_var.set("0%")
            frame_progreso.pack(side="bottom", fill="x", padx=10, pady=5)
            root.update_idletasks()
            root.geometry("")

            avance = 100 // len(descargas)
            base = 0
            for asset in descargas:
                nombre = asset["name"]
                url = asset["browser_download_url"]
                destino = os.path.join(exe_dir, nombre)
                logger.info(f"Descargando {nombre} desde {url} a {destino}")

                try:
                    urllib.request.urlretrieve(
                        url,
                        destino,
                        reporthook=crear_hook(base, avance, barra_progreso, porcentaje_var, root, status_var)
                    )
                except Exception as e:
                    logger.error(f"Error al descargar {nombre}: {e}")
                    messagebox.showerror("Error", f"No se pudo descargar {nombre}. Intenta nuevamente.")
                    return

                base += avance

            barra_progreso["value"] = 100
            porcentaje_var.set("100%")
            status_var.set("Actualización descargada correctamente.")
            root.update_idletasks()
            root.geometry("")

            def ocultar():
                status_var.set("")
                frame_progreso.pack_forget()
                status_label.pack_forget()
                root.geometry("")

            root.after(3000, ocultar)

            nuevo_path = destino
            logger.info(f"Lanzando nuevo ejecutable: {nuevo_path}")
            messagebox.showinfo("Actualización", f"Se lanzará la nueva versión ({ultima_version}) ahora.")

            try:
                subprocess.Popen([nuevo_path])
                actualizar_version_local(ultima_version)
                logger.info(f"Archivo version.txt actualizado a v{ultima_version}")
            except Exception as e:
                logger.error(f"No se pudo lanzar la nueva versión: {e}")
            finally:
                logger.info("===== FIN DE PROCESO DE ACTUALIZACIÓN =====")
                sys.exit()

    except Exception as e:
        logger.exception(f"Error al verificar actualización desde {URL_API}")
        messagebox.showerror("Error", f"No se pudo verificar actualización:\n{e}")
        status_var.set("Error al verificar actualización")
        root.after(5000, lambda: status_var.set(""))
        frame_progreso.pack_forget()
        status_label.pack_forget()
        root.geometry("")
        logger.info("===== FIN DE PROCESO DE ACTUALIZACIÓN (error inesperado) =====")

def verificar_version_disponible():
    """
    Compara la versión local con la versión más reciente publicada en GitHub.
    Retorna True si hay una versión nueva disponible.
    """
    try:
        context = ssl.create_default_context(cafile=certifi.where())
        with urllib.request.urlopen(URL_API, context=context) as response:
            data = json.loads(response.read())
            ultima_version = data["tag_name"].lstrip("v")

        version_local = obtener_version_actual()
        return version_local != ultima_version

    except Exception as e:
        logger.warning(f"No se pudo verificar la versión disponible: {e}")
        return False
