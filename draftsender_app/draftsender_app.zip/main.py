import os
import sys
import atexit
import requests
import subprocess
from tkinter import Tk, Toplevel, Label, Entry, Button, messagebox
from draftsender_app.logger_utils import configurar_logger
from draftsender_app.gui import DraftSenderApp
from draftsender_app.ui_utils import get_data_path
from draftsender_app.version import obtener_version_github
from draftsender_app.elimina_v_anterior import eliminar_ejecutable_anterior_si_es_necesario

def abrir_outlook_clasico():
    """
        Intenta abrir el acceso directo de Outlook clásico desde el menú de inicio.
        Imprime un mensaje indicando si se encontró o no el acceso directo.
        """
    ruta_acceso_directo = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Outlook (classic).lnk"
    if os.path.exists(ruta_acceso_directo):
        subprocess.Popen(['cmd', '/c', 'start', '', ruta_acceso_directo], shell=True)
        print("Se abrió Outlook clásico desde acceso directo.")
    else:
        print("No se encontró el acceso directo de Outlook clásico.")

def solicitar_nombre_usuario(root: Tk) -> str:
    """
        Solicita el nombre del usuario. Si ya fue ingresado previamente, lo recupera desde un archivo.
        En caso contrario, muestra una ventana emergente para ingresarlo y lo guarda.

        Args:
            root (Tk): Ventana principal de la aplicación.

        Returns:
            str: Nombre del usuario ingresado o recuperado.
        """
    data_dir = get_data_path()
    user_file = os.path.join(data_dir, "user.txt")

    if os.path.exists(user_file):
        with open(user_file, "r", encoding="utf-8") as f:
            return f.read().strip()

    nombre_usuario = None

    def guardar_nombre():
        nonlocal nombre_usuario
        valor = entry_nombre.get().strip()
        if valor:
            with open(user_file, "w", encoding="utf-8") as f:
                f.write(valor)
            nombre_usuario = valor
        ventana.destroy()

    def cerrar_app():
        root.destroy()
        sys.exit()

    ventana = Toplevel(root)
    ventana.title("¡Bienvenido a DraftSender!")
    ventana.geometry("400x180")
    ventana.resizable(False, False)
    ventana.grab_set()

    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    icon_path = os.path.join(base_path, "config", "icon.ico")
    if os.path.exists(icon_path):
        try:
            ventana.iconbitmap(icon_path)
        except Exception:
            pass

    Label(ventana, text="Por favor, escribe tu nombre para continuar:", font=("Arial", 11)).pack(pady=(20, 5))
    Label(ventana, text="(Ej. Nombre_Apellido)", font=("Arial", 10)).pack(pady=(5, 5))
    entry_nombre = Entry(ventana, font=("Arial", 12), width=30)
    entry_nombre.pack(pady=5)

    Button(ventana, text="Entrar", command=guardar_nombre, font=("Arial", 10), width=15).pack(pady=10)
    ventana.protocol("WM_DELETE_WINDOW", cerrar_app)
    root.wait_window(ventana)

    return nombre_usuario.strip() if nombre_usuario else None

def cargar_icono_ventana(root: Tk) -> None:
    """
        Intenta cargar un ícono personalizado para la ventana principal de la app.

        Args:
            root (Tk): Ventana principal de la aplicación.
        """
    try:
        base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        icon_path = os.path.join(base_path, "config", "icon.ico")
        if os.path.exists(icon_path):
            root.iconbitmap(icon_path)
    except Exception:
        pass

def main() -> None:
    """
    Función principal que inicializa la aplicación DraftSender con manejo robusto de errores.
    """
    eliminar_ejecutable_anterior_si_es_necesario()

    global logger

    try:
        root = Tk()
        root.withdraw()

        # Paso 1: Solicitar nombre del usuario
        try:
            nombre_usuario = solicitar_nombre_usuario(root)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo solicitar el nombre del usuario:\n{e}")
            root.destroy()
            return

        # Paso 2: Validación si no se obtuvo nombre
        if not nombre_usuario:
            from draftsender_app.ui_utils import get_data_path
            user_file = os.path.join(get_data_path(), "user.txt")
            if os.path.exists(user_file):
                with open(user_file, "r", encoding="utf-8") as f:
                    nombre_usuario = f.read().strip()

        if not nombre_usuario or not root.winfo_exists():
            messagebox.showwarning("Inicio cancelado", "La aplicación no se puede iniciar sin nombre de usuario.")
            root.destroy()
            return

        # Paso 3: Configurar logger
        try:
            logger = configurar_logger(usuario=nombre_usuario)
            logger.info("Iniciando aplicación")
        except Exception as e:
            print(f"Fallo crítico al configurar el logger: {e}")
            messagebox.showerror("Logger", "No se pudo inicializar el sistema de registro.")
            return

        # Paso 4: Configurar GUI
        titulo_app = f"{obtener_version_github()} - {nombre_usuario}"
        root.title(titulo_app)

        try:
            cargar_icono_ventana(root)
            root.deiconify()
        except Exception as e:
            logger.warning(f"No se pudo cargar el ícono de la aplicación: {e}")

        # Paso 5: Iniciar interfaz principal
        try:
            DraftSenderApp(root, titulo_ventana=titulo_app)
            atexit.register(lambda: logger.info("Aplicación finalizada."))
            root.mainloop()
        except Exception as e:
            logger.exception("Fallo al cargar la interfaz principal")
            messagebox.showerror("Error crítico", f"No se pudo iniciar la interfaz principal:\n{e}")
            root.destroy()

    except Exception as e:
        if 'logger' in globals():
            logger.exception("Fallo inesperado en el arranque general")
        else:
            print(f"Fallo crítico antes de iniciar el logger: {e}")
        messagebox.showerror("Error grave", f"Ocurrió un error inesperado:\n{e}")
        raise

if __name__ == "__main__":
    main()