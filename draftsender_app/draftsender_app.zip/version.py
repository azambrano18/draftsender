__version__ = "v1.31"

def obtener_version_github(repo="azambrano18/draftsender"):
    """
    Obtiene la versión más reciente de la aplicación desde GitHub.

    Returns:
        str: Versión en formato texto si se obtiene correctamente, o "0.0.0" si hay error.
    """
    import requests
    try:
        url = f"https://api.github.com/repos/{repo}/releases/latest"
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            return r.json()["name"]
    except Exception:
        pass
    return __version__
